module.exports = {
    content: ["./src/**/*.{js,jsx,ts,tsx}"], // อย่าลืมใส่ path ด้วยนะลูก
    theme: {
        extend: {
            fontFamily: {
                bodoniSC: ['"Bodoni Moda SC"', 'serif'],
              }              
        },
      },
    plugins: [],
  }
  
  