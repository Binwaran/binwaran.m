const Blog = () => {
    return (
      <div className="w-full h-full z-[-1]">
        <img src="/coming-soon.png" alt="Nofffie picture" className="absolute top-8 sm:top-0 left-0 flex justify-center items-center w-[500px] drop-shadow-[0_5px_10px_rgba(0,0,0,0.3)] sm:w-[1500px] z-40"/>
      </div>
    );
  };
  
  export default Blog;