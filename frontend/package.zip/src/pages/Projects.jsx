const Projects = () => {
    return (
      <div>
        <h1>Project Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Projects;