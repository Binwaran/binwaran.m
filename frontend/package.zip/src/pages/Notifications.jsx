const Notifications = () => {
    return (
      <div>
        <h1>Home Page</h1>
        <p>Welcome to my personal portfolio.</p>
      </div>
    );
  };
  
  export default Notifications;